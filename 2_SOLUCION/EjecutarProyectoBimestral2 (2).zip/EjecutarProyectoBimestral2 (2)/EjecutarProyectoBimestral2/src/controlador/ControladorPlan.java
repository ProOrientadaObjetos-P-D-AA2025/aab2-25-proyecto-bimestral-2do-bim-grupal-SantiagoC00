
package controlador;

import java.util.ArrayList;
import java.util.List;
import modelo.PlanCelular;





    public class ControladorPlan {
    private List<PlanCelular> listaPlanes = new ArrayList<>();

    public boolean verificarLimitePlanes(int idCliente) {
        int contador = 0;
        for (PlanCelular plan : listaPlanes) {
            if (plan.getClienteId()== idCliente) {
                contador++;
            }
        }
        return contador >= 2;
    }

    // Método para agregar un plan a la lista
    public void insertarPlan(PlanCelular p) {
        listaPlanes.add(p);
    }

    public List<PlanCelular> getPlanes() {
        return listaPlanes;
    }
}



