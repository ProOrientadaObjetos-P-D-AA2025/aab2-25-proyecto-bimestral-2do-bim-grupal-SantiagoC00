package controlador;

import db.Conexion;
import modelo.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlanDAO {

    public boolean insertarPlan(PlanCelular plan) {
        String sql = "INSERT INTO planes(tipo, minutos, costoMinuto, megas, costoGiga, descuento, tarifaBase, cliente_id) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexion.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, plan.getTipo());
            pstmt.setInt(8, plan.getClienteId());

            switch (plan.getTipo()) {
                case "MINUTOS":
                    PlanPostPagoMinutos p1 = (PlanPostPagoMinutos) plan;
                    pstmt.setInt(2, p1.getMinutosNacionales() + p1.getMinutosInternacionales());
                    pstmt.setDouble(3, (p1.getCostoMinutoNacional() + p1.getCostoMinutoInternacional()) / 2);
                    pstmt.setNull(4, Types.REAL);
                    pstmt.setNull(5, Types.REAL);
                    pstmt.setNull(6, Types.REAL);
                    pstmt.setNull(7, Types.REAL);
                    break;
                case "MEGAS":
                    PlanPostPagoMegas p2 = (PlanPostPagoMegas) plan;
                    pstmt.setNull(2, Types.INTEGER);
                    pstmt.setNull(3, Types.REAL);
                    pstmt.setDouble(4, p2.getMegas());
                    pstmt.setDouble(5, p2.getCostoPorGiga());
                    pstmt.setNull(6, Types.REAL);
                    pstmt.setDouble(7, p2.getTarifaBase());
                    break;
                case "MINUTOS+MEGAS":
                    PlanPostPagoMinutosMegas p3 = (PlanPostPagoMinutosMegas) plan;
                    pstmt.setInt(2, p3.getMinutos());
                    pstmt.setDouble(3, p3.getCostoMinuto());
                    pstmt.setDouble(4, p3.getMegas());
                    pstmt.setDouble(5, p3.getCostoPorGiga());
                    pstmt.setNull(6, Types.REAL);
                    pstmt.setNull(7, Types.REAL);
                    break;
                case "ECONOMICO":
                    PlanPostPagoMinutosMegasEconomico p4 = (PlanPostPagoMinutosMegasEconomico) plan;
                    pstmt.setInt(2, p4.getMinutos());
                    pstmt.setDouble(3, p4.getCostoMinuto());
                    pstmt.setDouble(4, p4.getMegas());
                    pstmt.setDouble(5, p4.getCostoPorGiga());
                    pstmt.setDouble(6, p4.getDescuento());
                    pstmt.setNull(7, Types.REAL);
                    break;
            }

            int filas = pstmt.executeUpdate();
            if (filas > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    int idGenerado = rs.getInt(1);
                    plan.setId(idGenerado);
                }
                return true;
            }

        } catch (SQLException e) {
            System.out.println("Error al insertar plan: " + e.getMessage());
        }

        return false;
    }

    public int contarPlanesPorCliente(int clienteId) {
        String sql = "SELECT COUNT(*) FROM planes WHERE cliente_id = ?";
        try (Connection conn = Conexion.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, clienteId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println("Error al contar planes: " + e.getMessage());
        }
        return 0;
    }

    
}
