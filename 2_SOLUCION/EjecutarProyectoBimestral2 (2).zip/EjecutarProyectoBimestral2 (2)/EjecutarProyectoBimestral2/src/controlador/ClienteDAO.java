package controlador;

import db.Conexion;
import modelo.Cliente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    public int insertarCliente(Cliente cliente) {
    String sql = "INSERT INTO clientes(nombre, cedula, ciudad, marca, modelo, numeroCelular, pagoMensual, fechaUTPL, edad) " +
                 "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try (Connection conn = Conexion.conectar(); 
         PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

        pstmt.setString(1, cliente.getNombre());
        pstmt.setString(2, cliente.getCedula());
        pstmt.setString(3, cliente.getCiudad());
        pstmt.setString(4, cliente.getMarca());
        pstmt.setString(5, cliente.getModelo());
        pstmt.setString(6, cliente.getNumeroCelular());
        pstmt.setDouble(7, cliente.getPagoMensual());
        pstmt.setString(8, cliente.getFechaUTPL());
        pstmt.setInt(9, cliente.getEdad());

        int filasAfectadas = pstmt.executeUpdate();

        if (filasAfectadas > 0) {
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1); // ← ID generado
                }
            }
        }

    } catch (SQLException e) {
        System.out.println("Error al insertar cliente: " + e.getMessage());
    }

    return -1; // Error
}



    // LISTAR todos los clientes
    public List<Cliente> obtenerClientes() {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM clientes";

        try (Connection conn = Conexion.conectar(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Cliente cliente = new Cliente(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("cedula"),
                    rs.getString("ciudad"),
                    rs.getString("marca"),
                    rs.getString("modelo"),
                    rs.getString("numeroCelular"),
                    rs.getDouble("pagoMensual"),
                    rs.getString("fechaUTPL"),
                    rs.getInt("edad")
                );
                lista.add(cliente);
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener clientes: " + e.getMessage());
        }

        return lista;
    }

    // ACTUALIZAR cliente por ID
    public boolean actualizarCliente(Cliente cliente) {
        String sql = "UPDATE clientes SET nombre=?, cedula=?, ciudad=?, marca=?, modelo=?, numeroCelular=?, pagoMensual=?, fechaUTPL=?, edad=? WHERE id=?";

        try (Connection conn = Conexion.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cliente.getNombre());
            pstmt.setString(2, cliente.getCedula());
            pstmt.setString(3, cliente.getCiudad());
            pstmt.setString(4, cliente.getMarca());
            pstmt.setString(5, cliente.getModelo());
            pstmt.setString(6, cliente.getNumeroCelular());
            pstmt.setDouble(7, cliente.getPagoMensual());
            pstmt.setString(8, cliente.getFechaUTPL());
            pstmt.setInt(9, cliente.getEdad());
            pstmt.setInt(10, cliente.getId());

            pstmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al actualizar cliente: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR cliente por ID
    public boolean eliminarCliente(int id) {
        String sql = "DELETE FROM clientes WHERE id = ?";

        try (Connection conn = Conexion.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al eliminar cliente: " + e.getMessage());
            return false;
        }
    }
}