package modelo;

public class PlanPostPagoMinutosMegasEconomico extends PlanCelular {
    private int minutos;
    private double costoMinuto;
    private double megas;         // en GB
    private double costoPorGiga;
    private double descuento;

    public PlanPostPagoMinutosMegasEconomico(int id, int clienteId, int minutos, double costoMinuto,
                                              double megas, double costoPorGiga, double descuento) {
        super(id, "ECONOMICO", clienteId);
        this.minutos = minutos;
        this.costoMinuto = costoMinuto;
        this.megas = megas;
        this.costoPorGiga = costoPorGiga;
        this.descuento = descuento;
    }

    public PlanPostPagoMinutosMegasEconomico(int clienteId, int minutos, double costoMinuto,
                                              double megas, double costoPorGiga, double descuento) {
        super("ECONOMICO", clienteId);
        this.minutos = minutos;
        this.costoMinuto = costoMinuto;
        this.megas = megas;
        this.costoPorGiga = costoPorGiga;
        this.descuento = descuento;
    }

    @Override
    public double calcularPagoMensual() {
        double subtotal = (minutos * costoMinuto) + (megas * costoPorGiga);
        return subtotal - (subtotal * descuento / 100);
    }

    // Getters y Setters

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public double getCostoMinuto() {
        return costoMinuto;
    }

    public void setCostoMinuto(double costoMinuto) {
        this.costoMinuto = costoMinuto;
    }

    public double getMegas() {
        return megas;
    }

    public void setMegas(double megas) {
        this.megas = megas;
    }

    public double getCostoPorGiga() {
        return costoPorGiga;
    }

    public void setCostoPorGiga(double costoPorGiga) {
        this.costoPorGiga = costoPorGiga;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    @Override
    public String toString() {
        return "PlanPostPagoMinutosMegasEconomico{" +
                "minutos=" + minutos +
                ", costoMinuto=" + costoMinuto +
                ", megas=" + megas +
                ", costoPorGiga=" + costoPorGiga +
                ", descuento=" + descuento +
                "%, pagoTotal=" + calcularPagoMensual() +
                '}';
    }
}
