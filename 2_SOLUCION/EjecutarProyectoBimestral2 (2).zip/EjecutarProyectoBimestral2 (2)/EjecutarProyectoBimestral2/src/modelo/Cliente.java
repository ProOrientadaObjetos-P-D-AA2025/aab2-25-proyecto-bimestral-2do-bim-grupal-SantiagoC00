package modelo;

public class Cliente {
    private int id;
    private String nombre;
    private String cedula;
    private String ciudad;
    private String marca;
    private String modelo;
    private String numeroCelular;
    private double pagoMensual;
    private String fechaUTPL;
    private int edad;

    public Cliente() {
        // Constructor vacio para usar JDBC
    }

    public Cliente(int id, String nombre, String cedula, String ciudad, String marca, String modelo,
                   String numeroCelular, double pagoMensual, String fechaUTPL, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.cedula = cedula;
        this.ciudad = ciudad;
        this.marca = marca;
        this.modelo = modelo;
        this.numeroCelular = numeroCelular;
        this.pagoMensual = pagoMensual;
        this.fechaUTPL = fechaUTPL;
        this.edad = edad;
    }

    public Cliente(String nombre, String cedula, String ciudad, String marca, String modelo,
                   String numeroCelular, double pagoMensual, String fechaUTPL, int edad) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.ciudad = ciudad;
        this.marca = marca;
        this.modelo = modelo;
        this.numeroCelular = numeroCelular;
        this.pagoMensual = pagoMensual;
        this.fechaUTPL = fechaUTPL;
        this.edad = edad;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getNumeroCelular() {
        return numeroCelular;
    }

    public void setNumeroCelular(String numeroCelular) {
        this.numeroCelular = numeroCelular;
    }

    public double getPagoMensual() {
        return pagoMensual;
    }

    public void setPagoMensual(double pagoMensual) {
        this.pagoMensual = pagoMensual;
    }

    public String getFechaUTPL() {
        return fechaUTPL;
    }

    public void setFechaUTPL(String fechaUTPL) {
        this.fechaUTPL = fechaUTPL;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", cedula='" + cedula + '\'' +
                ", ciudad='" + ciudad + '\'' +
                ", marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", numeroCelular='" + numeroCelular + '\'' +
                ", pagoMensual=" + pagoMensual +
                ", fechaUTPL='" + fechaUTPL + '\'' +
                ", edad=" + edad +
                '}';
    }
}
