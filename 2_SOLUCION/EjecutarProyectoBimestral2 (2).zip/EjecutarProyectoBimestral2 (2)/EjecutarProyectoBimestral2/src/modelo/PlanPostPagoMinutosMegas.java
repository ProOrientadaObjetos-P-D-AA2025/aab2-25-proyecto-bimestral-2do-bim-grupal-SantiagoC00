package modelo;

public class PlanPostPagoMinutosMegas extends PlanCelular {
    private int minutos;
    private double costoMinuto;
    private double megas;           // en GB
    private double costoPorGiga;

    public PlanPostPagoMinutosMegas(int id, int clienteId, int minutos, double costoMinuto, double megas, double costoPorGiga) {
        super(id, "MINUTOS+MEGAS", clienteId);
        this.minutos = minutos;
        this.costoMinuto = costoMinuto;
        this.megas = megas;
        this.costoPorGiga = costoPorGiga;
    }

    public PlanPostPagoMinutosMegas(int clienteId, int minutos, double costoMinuto, double megas, double costoPorGiga) {
        super("MINUTOS+MEGAS", clienteId);
        this.minutos = minutos;
        this.costoMinuto = costoMinuto;
        this.megas = megas;
        this.costoPorGiga = costoPorGiga;
    }

    @Override
    public double calcularPagoMensual() {
        return (minutos * costoMinuto) + (megas * costoPorGiga);
    }

    // Getters y Setters

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public double getCostoMinuto() {
        return costoMinuto;
    }

    public void setCostoMinuto(double costoMinuto) {
        this.costoMinuto = costoMinuto;
    }

    public double getMegas() {
        return megas;
    }

    public void setMegas(double megas) {
        this.megas = megas;
    }

    public double getCostoPorGiga() {
        return costoPorGiga;
    }

    public void setCostoPorGiga(double costoPorGiga) {
        this.costoPorGiga = costoPorGiga;
    }

    @Override
    public String toString() {
        return "PlanPostPagoMinutosMegas{" +
                "minutos=" + minutos +
                ", costoMinuto=" + costoMinuto +
                ", megas=" + megas +
                ", costoPorGiga=" + costoPorGiga +
                ", pagoTotal=" + calcularPagoMensual() +
                '}';
    }
}
