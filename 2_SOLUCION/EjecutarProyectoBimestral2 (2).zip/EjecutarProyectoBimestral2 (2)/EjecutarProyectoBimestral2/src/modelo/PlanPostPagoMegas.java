package modelo;

public class PlanPostPagoMegas extends PlanCelular {
    private double megas;           // en GB
    private double costoPorGiga;
    private double tarifaBase;

    public PlanPostPagoMegas(int id, int clienteId, double megas, double costoPorGiga, double tarifaBase) {
        super(id, "MEGAS", clienteId);
        this.megas = megas;
        this.costoPorGiga = costoPorGiga;
        this.tarifaBase = tarifaBase;
    }

    public PlanPostPagoMegas(int clienteId, double megas, double costoPorGiga, double tarifaBase) {
        super("MEGAS", clienteId);
        this.megas = megas;
        this.costoPorGiga = costoPorGiga;
        this.tarifaBase = tarifaBase;
    }

    @Override
    public double calcularPagoMensual() {
        return (megas * costoPorGiga) + tarifaBase;
    }


    public double getMegas() {
        return megas;
    }

    public void setMegas(double megas) {
        this.megas = megas;
    }

    public double getCostoPorGiga() {
        return costoPorGiga;
    }

    public void setCostoPorGiga(double costoPorGiga) {
        this.costoPorGiga = costoPorGiga;
    }

    public double getTarifaBase() {
        return tarifaBase;
    }

    public void setTarifaBase(double tarifaBase) {
        this.tarifaBase = tarifaBase;
    }

    @Override
    public String toString() {
        return "PlanPostPagoMegas{" +
                "megas=" + megas +
                ", costoPorGiga=" + costoPorGiga +
                ", tarifaBase=" + tarifaBase +
                ", pagoTotal=" + calcularPagoMensual() +
                '}';
    }
}
