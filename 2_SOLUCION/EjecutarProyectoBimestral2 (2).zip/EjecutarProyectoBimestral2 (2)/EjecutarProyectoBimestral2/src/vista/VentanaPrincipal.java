
package vista;

import controlador.ClienteDAO;
import controlador.FacturaDAO;
import controlador.PlanDAO;
import modelo.*;

import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import controlador.ControladorPlan;


public class VentanaPrincipal extends JFrame {
    private JTextField txtNombre, txtCedula, txtCiudad, txtMarca, txtModelo,
            txtNumeroCelular, txtPagoMensual, txtFechaUTPL, txtEdad;
    private JComboBox<String> cmbTipoPlan;
    private JButton btnGuardarCliente, btnAgregarPlan, btnGenerarFactura, btnMostrarFacturas;

    private Cliente cliente;
    private final ControladorPlan controladorPlan = new ControladorPlan();

    private final List<PlanCelular> planes = new ArrayList<>();

    public VentanaPrincipal() {
        setTitle("Sistema Mov-UTPL");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(13, 2));

        txtNombre = new JTextField();
        txtCedula = new JTextField();
        txtCiudad = new JTextField();
        txtMarca = new JTextField();
        txtModelo = new JTextField();
        txtNumeroCelular = new JTextField();
        txtPagoMensual = new JTextField();
        txtFechaUTPL = new JTextField();
        txtEdad = new JTextField();

        cmbTipoPlan = new JComboBox<>(new String[]{"MINUTOS", "MEGAS", "MINUTOS+MEGAS", "ECONOMICO"});

        btnGuardarCliente = new JButton("Guardar Cliente");
        btnAgregarPlan = new JButton("Agregar Plan");
        btnGenerarFactura = new JButton("Generar Factura");
        btnMostrarFacturas = new JButton("Mostrar Facturas ...");

        add(new JLabel("Nombre:")); add(txtNombre);
        add(new JLabel("Cedula:")); add(txtCedula);
        add(new JLabel("Ciudad:")); add(txtCiudad);
        add(new JLabel("Marca:")); add(txtMarca);
        add(new JLabel("Modelo:")); add(txtModelo);
        add(new JLabel("Nro Celular:")); add(txtNumeroCelular);
        add(new JLabel("Pago Base:")); add(txtPagoMensual);
        add(new JLabel("Fecha UTPL (YYYY-MM-DD):")); add(txtFechaUTPL);
        add(new JLabel("Edad:")); add(txtEdad);
        add(new JLabel("Tipo de Plan:")); add(cmbTipoPlan);
        add(btnGuardarCliente); add(btnAgregarPlan);
        add(btnGenerarFactura); add(btnMostrarFacturas);

        btnAgregarPlan.setEnabled(false);
        btnGenerarFactura.setEnabled(false);

        btnGuardarCliente.addActionListener(e -> {
            
            try {
                cliente = new Cliente(
                        txtNombre.getText(),
                        txtCedula.getText(),
                        txtCiudad.getText(),
                        txtMarca.getText(),
                        txtModelo.getText(),
                        txtNumeroCelular.getText(),
                        Double.parseDouble(txtPagoMensual.getText()),
                        txtFechaUTPL.getText(),
                        Integer.parseInt(txtEdad.getText())
                );

                ClienteDAO clienteDAO = new ClienteDAO();
                int idGenerado = clienteDAO.insertarCliente(cliente);
                if (idGenerado > 0) {
                    cliente.setId(idGenerado);
                    JOptionPane.showMessageDialog(this, "Cliente insertado correctamente. ID: " + idGenerado);
                    btnAgregarPlan.setEnabled(true);
                    btnGuardarCliente.setEnabled(false);
                } else {
                    JOptionPane.showMessageDialog(this, "Error al insertar cliente.", "ERROR", JOptionPane.ERROR_MESSAGE);
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Datos inválidos: " + ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnAgregarPlan.addActionListener(e -> {
            
            if (cliente == null) {
                JOptionPane.showMessageDialog(this, "Primero debe registrar un cliente.", "ERROR", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (controladorPlan.verificarLimitePlanes(cliente.getId())) {
                    JOptionPane.showMessageDialog(this, "Este cliente ya tiene 2 planes registrados. No puede agregar más.", "Límite alcanzado", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String tipo = (String) cmbTipoPlan.getSelectedItem();
            PlanCelular plan = null;
            switch (tipo) {
                case "MINUTOS":
                    plan = new PlanPostPagoMinutos(cliente.getId(), 75, 0.3, 75, 0.3);
                    break;
                case "MEGAS":
                    plan = new PlanPostPagoMegas(cliente.getId(), 10.0, 2.5, 5.0);
                    break;
                case "MINUTOS+MEGAS":
                    plan = new PlanPostPagoMinutosMegas(cliente.getId(), 100, 0.25, 5.0, 2.0);
                    break;
                case "ECONOMICO":
                    plan = new PlanPostPagoMinutosMegasEconomico(cliente.getId(), 200, 0.2, 10.0, 1.5, 10);
                    break;
            }

            if (plan != null) {
                plan.calcularPagoMensual();
                controladorPlan.insertarPlan(plan); // 🔁 se guarda también en lista del controlador
                planes.add(plan);                   // lista de ventana
                PlanDAO planDAO = new PlanDAO();
                planDAO.insertarPlan(plan);
                JOptionPane.showMessageDialog(this, "Plan agregado correctamente.");
        btnGenerarFactura.setEnabled(true);
    }
        });

        btnGenerarFactura.addActionListener(e -> {
            if (planes.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Debe agregar al menos un plan.", "ERROR", JOptionPane.ERROR_MESSAGE);
                return;
            }

            FacturaDAO facturaDAO = new FacturaDAO();
            double total = 0;
            LocalDate hoy = LocalDate.now();
            for (PlanCelular plan : planes) {
                double pago = plan.calcularPagoMensual();
                total += pago;
                facturaDAO.insertarFactura(new Factura(0, cliente.getId(), plan.getId(), pago, hoy.toString()));
            }

            JOptionPane.showMessageDialog(this, "Factura generada. Total a pagar: $" + total);
            planes.clear();
            btnGenerarFactura.setEnabled(false);
        });

        btnMostrarFacturas.addActionListener(e -> {
            FacturaDAO dao = new FacturaDAO();
            List<Factura> lista = dao.obtenerFacturasPorCliente(cliente.getId());
            StringBuilder sb = new StringBuilder();
            for (Factura f : lista) {
                sb.append("Factura ID: ").append(f.getId())
                        .append(", Total: $").append(f.getTotalPago())
                        .append(", Fecha: ").append(f.getFechaEmision()).append("\n");
            }
            JOptionPane.showMessageDialog(this, sb.toString());
        });

        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        JButton btnNuevaPrueba = new JButton("Nueva Prueba");
        btnNuevaPrueba.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                txtNombre.setText("");
                txtCedula.setText("");
                txtCiudad.setText("");
                txtMarca.setText("");
                txtModelo.setText("");
                txtNumeroCelular.setText("");
                txtPagoMensual.setText("");
                txtFechaUTPL.setText("");
                txtEdad.setText("");
                cmbTipoPlan.setSelectedIndex(0);
                planes.clear();
                btnGuardarCliente.setEnabled(true);
                btnAgregarPlan.setEnabled(false);
                btnGenerarFactura.setEnabled(false);
            }
        });
        this.add(btnNuevaPrueba);
    }

    public static void main(String[] args) {
        new VentanaPrincipal();
    }
}
