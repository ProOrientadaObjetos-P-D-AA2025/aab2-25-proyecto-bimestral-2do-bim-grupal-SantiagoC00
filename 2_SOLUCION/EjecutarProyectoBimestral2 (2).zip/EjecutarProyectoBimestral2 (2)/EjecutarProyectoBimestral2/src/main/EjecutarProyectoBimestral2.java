package main;

import controlador.ClienteDAO;
import controlador.FacturaDAO;
import controlador.PlanDAO;
import modelo.*;

import java.util.*;
import java.time.LocalDate;

public class EjecutarProyectoBimestral2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ClienteDAO clienteDAO = new ClienteDAO();
        PlanDAO planDAO = new PlanDAO();
        FacturaDAO facturaDAO = new FacturaDAO();

        System.out.println("=== INGRESO DE DATOS DEL CLIENTE ===");
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Cédula: ");
        String cedula = sc.nextLine();
        System.out.print("Ciudad: ");
        String ciudad = sc.nextLine();
        System.out.print("Marca celular: ");
        String marca = sc.nextLine();
        System.out.print("Modelo celular: ");
        String modelo = sc.nextLine();
        System.out.print("Número celular: ");
        String numeroCelular = sc.nextLine();
        System.out.print("Pago mensual (base): ");
        double pagoMensual = sc.nextDouble(); sc.nextLine();
        System.out.print("Fecha UTPL (YYYY-MM-DD): ");
        String fechaUTPL = sc.nextLine();
        System.out.print("Edad: ");
        int edad = sc.nextInt(); sc.nextLine();

        // Crear cliente
        Cliente cliente = new Cliente(0, nombre, cedula, ciudad, marca, modelo, numeroCelular, pagoMensual, fechaUTPL, edad);

        // Insertar cliente y obtener ID generado
        int clienteId = clienteDAO.insertarCliente(cliente);
        if (clienteId > 0) {
            cliente.setId(clienteId);  // importante: asignar el ID al objeto cliente
            System.out.println("Cliente insertado correctamente.");
        } else {
            System.out.println("Error al insertar cliente.");
            return;
        }

        // PRUEBAS TDD DE PLANES
        System.out.println("\n=== PRUEBAS TDD DE PLANES ===");
        List<PlanCelular> planes = new ArrayList<>();
        LocalDate hoy = LocalDate.now();

        // 1. PlanPostPagoMinutos
        PlanPostPagoMinutos planMin = new PlanPostPagoMinutos(0, cliente.getId(), 75, 0.3, 75, 0.3);
        planMin.calcularPagoMensual();
        planDAO.insertarPlan(planMin);
        planes.add(planMin);

        // 2. PlanPostPagoMegas
        PlanPostPagoMegas planMegas = new PlanPostPagoMegas(0, cliente.getId(), 10.0, 2.5, 5.0);
        planMegas.calcularPagoMensual();
        planDAO.insertarPlan(planMegas);
        planes.add(planMegas);

        // 3. PlanPostPagoMinutosMegas
        PlanPostPagoMinutosMegas planMix = new PlanPostPagoMinutosMegas(0, cliente.getId(), 100, 0.25, 5.0, 2.0);
        planMix.calcularPagoMensual();
        planDAO.insertarPlan(planMix);
        planes.add(planMix);

        // 4. PlanPostPagoMinutosMegasEconomico
        PlanPostPagoMinutosMegasEconomico planEco = new PlanPostPagoMinutosMegasEconomico(0, cliente.getId(), 200, 0.2, 10.0, 1.5, 10);
        planEco.calcularPagoMensual();
        planDAO.insertarPlan(planEco);
        planes.add(planEco);

        // GENERAR FACTURAS
        double total = 0;
        for (PlanCelular plan : planes) {
            Factura factura = new Factura(0, cliente.getId(), 0, plan.getPagoTotal(), hoy.toString());
            facturaDAO.insertarFactura(factura);
            total += plan.getPagoTotal();
        }

        // ===MOSTRAR RESULTADO
        System.out.println("\n=== RESUMEN ===");
        System.out.println("Cliente: " + cliente.getNombre());
        System.out.println("Cédula: " + cliente.getCedula());
        System.out.println("Número de planes: " + planes.size());
        for (PlanCelular p : planes) {
            System.out.println(p);
        }
        System.out.printf("Total a pagar: $%.2f\n", total);

        sc.close();
    }
}
