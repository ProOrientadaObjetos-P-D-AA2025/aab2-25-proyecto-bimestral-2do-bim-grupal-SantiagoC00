package controlador;

import db.Conexion;
import modelo.Factura;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FacturaDAO {

    // INSERTAR una factura
    public boolean insertarFactura(Factura factura) {
        String sql = "INSERT INTO facturas(cliente_id, plan_id, totalPago, fechaEmision) VALUES (?, ?, ?, ?)";

        try (Connection conn = Conexion.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, factura.getClienteId());
            pstmt.setInt(2, factura.getPlanId());
            pstmt.setDouble(3, factura.getTotalPago());
            pstmt.setString(4, factura.getFechaEmision());
            pstmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al insertar factura: " + e.getMessage());
            return false;
        }
    }

    // OBTENER todas las facturas
    public List<Factura> obtenerFacturas() {
        List<Factura> lista = new ArrayList<>();
        String sql = "SELECT * FROM facturas";

        try (Connection conn = Conexion.conectar(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Factura factura = new Factura(
                        rs.getInt("id"),
                        rs.getInt("cliente_id"),
                        rs.getInt("plan_id"),
                        rs.getDouble("totalPago"),
                        rs.getString("fechaEmision")
                );
                lista.add(factura);
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener facturas: " + e.getMessage());
        }

        return lista;
    }

    // OBTENER facturas por ID de cliente
    public List<Factura> obtenerFacturasPorCliente(int clienteId) {
        List<Factura> lista = new ArrayList<>();
        String sql = "SELECT * FROM facturas WHERE cliente_id = ?";

        try (Connection conn = Conexion.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, clienteId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Factura factura = new Factura(
                        rs.getInt("id"),
                        rs.getInt("cliente_id"),
                        rs.getInt("plan_id"),
                        rs.getDouble("totalPago"),
                        rs.getString("fechaEmision")
                );
                lista.add(factura);
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener facturas por cliente: " + e.getMessage());
        }

        return lista;
    }

    // ELIMINAR factura por ID
    public boolean eliminarFactura(int id) {
        String sql = "DELETE FROM facturas WHERE id = ?";

        try (Connection conn = Conexion.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al eliminar factura: " + e.getMessage());
            return false;
        }
    }
}
