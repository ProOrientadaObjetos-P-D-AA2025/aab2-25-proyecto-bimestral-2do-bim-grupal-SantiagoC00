package modelo;

public class Factura {
    private int id;
    private int clienteId;
    private int planId;
    private double totalPago;
    private String fechaEmision;

    public Factura() {
    }

    public Factura(int id, int clienteId, int planId, double totalPago, String fechaEmision) {
        this.id = id;
        this.clienteId = clienteId;
        this.planId = planId;
        this.totalPago = totalPago;
        this.fechaEmision = fechaEmision;
    }

    public Factura(int clienteId, int planId, double totalPago, String fechaEmision) {
        this.clienteId = clienteId;
        this.planId = planId;
        this.totalPago = totalPago;
        this.fechaEmision = fechaEmision;
    }

    // Getters y Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClienteId() {
        return clienteId;
    }

    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }

    public int getPlanId() {
        return planId;
    }

    public void setPlanId(int planId) {
        this.planId = planId;
    }

    public double getTotalPago() {
        return totalPago;
    }

    public void setTotalPago(double totalPago) {
        this.totalPago = totalPago;
    }

    public String getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    @Override
    public String toString() {
        return "Factura{" +
                "id=" + id +
                ", clienteId=" + clienteId +
                ", planId=" + planId +
                ", totalPago=" + totalPago +
                ", fechaEmision='" + fechaEmision + '\'' +
                '}';
    }
}
