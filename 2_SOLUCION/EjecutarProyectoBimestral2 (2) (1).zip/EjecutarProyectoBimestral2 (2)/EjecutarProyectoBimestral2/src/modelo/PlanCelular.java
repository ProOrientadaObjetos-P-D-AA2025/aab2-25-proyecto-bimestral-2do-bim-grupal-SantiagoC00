package modelo;

public abstract class PlanCelular {
    protected int id;
    protected String tipo;
    protected int clienteId;

    public PlanCelular() {
    }

    public PlanCelular(int id, String tipo, int clienteId) {
        this.id = id;
        this.tipo = tipo;
        this.clienteId = clienteId;
    }

    public PlanCelular(String tipo, int clienteId) {
        this.tipo = tipo;
        this.clienteId = clienteId;
    }

    // Método polimorfico
    public abstract double calcularPagoMensual();

    // Getters y Setters
    public int getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public int getClienteId() {
        return clienteId;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }
}
