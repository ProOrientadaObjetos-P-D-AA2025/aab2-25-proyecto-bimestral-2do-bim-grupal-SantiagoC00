package main;

import controlador.ClienteDAO;
import controlador.PlanDAO;
import controlador.FacturaDAO;

import modelo.*;

import java.util.List;

public class EjecutarProyectoBimestral2 {
    public static void main(String[] args) {
        // === 1. Crear Cliente ===
        Cliente cliente = new Cliente("Nahum Caraguay", "1105531122", "Loja",
                "Samsung", "A53", "0998887766", 0.0, "2025-07-22", 21);

        ClienteDAO clienteDAO = new ClienteDAO();
        boolean clienteInsertado = clienteDAO.insertarCliente(cliente);

        if (clienteInsertado) {
            System.out.println("Cliente insertado correctamente.");
        } else {
            System.out.println("Error al insertar cliente.");
            return;
        }

        // === 2. Obtener ID del cliente insertado ===
        List<Cliente> clientes = clienteDAO.obtenerClientes();
        int clienteId = clientes.get(clientes.size() - 1).getId(); // último ingresado

        // === 3. Crear 2 planes para ese cliente ===
        PlanPostPagoMinutos plan1 = new PlanPostPagoMinutos(clienteId, 100, 0.10, 50, 0.50);
        PlanPostPagoMegas plan2 = new PlanPostPagoMegas(clienteId, 10, 2.5, 5.0);

        PlanDAO planDAO = new PlanDAO();
        boolean plan1Insertado = planDAO.insertarPlan(plan1);
        boolean plan2Insertado = planDAO.insertarPlan(plan2);

        if (plan1Insertado && plan2Insertado) {
            System.out.println("Planes insertados correctamente.");
        } else {
            System.out.println("Error al insertar uno o ambos planes.");
            return;
        }

        // === 4. Obtener los planes del cliente desde la BD ===
        List<PlanCelular> planes = planDAO.obtenerPlanes();

        double totalPago = 0;
        int plan1Id = 0;
        int plan2Id = 0;

        for (PlanCelular plan : planes) {
            if (plan.getClienteId() == clienteId) {
                totalPago += plan.calcularPagoMensual();
                System.out.println(plan);
                if (plan1Id == 0) {
                    plan1Id = plan.getId();
                } else {
                    plan2Id = plan.getId();
                }
            }
        }

        // === 5. Insertar factura por cada plan ===
        FacturaDAO facturaDAO = new FacturaDAO();
        boolean factura1Insertada = facturaDAO.insertarFactura(
                new Factura(clienteId, plan1Id, plan1.calcularPagoMensual(), "2025-07-22")
        );
        boolean factura2Insertada = facturaDAO.insertarFactura(
                new Factura(clienteId, plan2Id, plan2.calcularPagoMensual(), "2025-07-22")
        );

        if (factura1Insertada && factura2Insertada) {
            System.out.println("Facturas generadas correctamente.");
        } else {
            System.out.println("Error al generar una o ambas facturas.");
        }

        // === 6. Mostrar resumen ===
        System.out.println("Resumen:");
        System.out.println("Cliente: " + cliente.getNombre());
        System.out.println("Cédula: " + cliente.getCedula());
        System.out.println("Número de planes: 2");
        System.out.println("Total a pagar: $" + totalPago);
    }
}
