package controlador;

import db.Conexion;
import modelo.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlanDAO {
    public boolean clienteTieneMenosDeDosPlanes(int clienteId) {
        String sql = "SELECT COUNT(*) FROM planes WHERE cliente_id = ?";
        try (Connection conn = Conexion.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, clienteId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) < 2;
            }
        } catch (SQLException e) {
            System.out.println("Error al verificar cantidad de planes por cliente: " + e.getMessage());
        }
        return false;
    }

    // INSERTAR  tipo de plan
    public boolean insertarPlan(PlanCelular plan) {
        //verificacion de si tiene mas de 2 planes 
        if (!clienteTieneMenosDeDosPlanes(plan.getClienteId())) {
            System.out.println("No se puede insertar el plan: el cliente ya tiene 2 planes asignados.");
            return false;
        }
        String sql = "INSERT INTO planes(tipo, minutos, costoMinuto, megas, costoGiga, descuento, tarifaBase, cliente_id) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexion.conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, plan.getTipo());
            pstmt.setInt(8, plan.getClienteId());

            //pstmt.setString(1, plan.getTipo());
            //pstmt.setInt(8, plan.getClienteId());

            // Casteo según tipo de plan
            switch (plan.getTipo()) {
                case "MINUTOS":
                    PlanPostPagoMinutos p1 = (PlanPostPagoMinutos) plan;
                    pstmt.setInt(2, p1.getMinutosNacionales() + p1.getMinutosInternacionales());
                    pstmt.setDouble(3, (p1.getCostoMinutoNacional() + p1.getCostoMinutoInternacional()) / 2);
                    pstmt.setNull(4, Types.REAL);
                    pstmt.setNull(5, Types.REAL);
                    pstmt.setNull(6, Types.REAL);
                    pstmt.setNull(7, Types.REAL);
                    break;
                case "MEGAS":
                    PlanPostPagoMegas p2 = (PlanPostPagoMegas) plan;
                    pstmt.setNull(2, Types.INTEGER);
                    pstmt.setNull(3, Types.REAL);
                    pstmt.setDouble(4, p2.getMegas());
                    pstmt.setDouble(5, p2.getCostoPorGiga());
                    pstmt.setNull(6, Types.REAL);
                    pstmt.setDouble(7, p2.getTarifaBase());
                    break;
                case "MINUTOS+MEGAS":
                    PlanPostPagoMinutosMegas p3 = (PlanPostPagoMinutosMegas) plan;
                    pstmt.setInt(2, p3.getMinutos());
                    pstmt.setDouble(3, p3.getCostoMinuto());
                    pstmt.setDouble(4, p3.getMegas());
                    pstmt.setDouble(5, p3.getCostoPorGiga());
                    pstmt.setNull(6, Types.REAL);
                    pstmt.setNull(7, Types.REAL);
                    break;
                case "ECONOMICO":
                    PlanPostPagoMinutosMegasEconomico p4 = (PlanPostPagoMinutosMegasEconomico) plan;
                    pstmt.setInt(2, p4.getMinutos());
                    pstmt.setDouble(3, p4.getCostoMinuto());
                    pstmt.setDouble(4, p4.getMegas());
                    pstmt.setDouble(5, p4.getCostoPorGiga());
                    pstmt.setDouble(6, p4.getDescuento());
                    pstmt.setNull(7, Types.REAL);
                    break;
                default:
                    System.out.println("Tipo de plan no reconocido.");
                    return false;
            }

            pstmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al insertar plan: " + e.getMessage());
            return false;
        }
    }

    // LISTAR todos los planes (como objetos PlanCelular)
    public List<PlanCelular> obtenerPlanes() {
        List<PlanCelular> lista = new ArrayList<>();
        String sql = "SELECT * FROM planes";

        try (Connection conn = Conexion.conectar(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String tipo = rs.getString("tipo");
                int id = rs.getInt("id");
                int clienteId = rs.getInt("cliente_id");

                switch (tipo) {
                    case "MINUTOS":
                        lista.add(new PlanPostPagoMinutos(
                                id, clienteId,
                                rs.getInt("minutos") / 2, rs.getDouble("costoMinuto"),
                                rs.getInt("minutos") / 2, rs.getDouble("costoMinuto")
                        ));
                        break;
                    case "MEGAS":
                        lista.add(new PlanPostPagoMegas(
                                id, clienteId,
                                rs.getDouble("megas"), rs.getDouble("costoGiga"), rs.getDouble("tarifaBase")
                        ));
                        break;
                    case "MINUTOS+MEGAS":
                        lista.add(new PlanPostPagoMinutosMegas(
                                id, clienteId,
                                rs.getInt("minutos"), rs.getDouble("costoMinuto"),
                                rs.getDouble("megas"), rs.getDouble("costoGiga")
                        ));
                        break;
                    case "ECONOMICO":
                        lista.add(new PlanPostPagoMinutosMegasEconomico(
                                id, clienteId,
                                rs.getInt("minutos"), rs.getDouble("costoMinuto"),
                                rs.getDouble("megas"), rs.getDouble("costoGiga"),
                                rs.getDouble("descuento")
                        ));
                        break;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener planes: " + e.getMessage());
        }

        return lista;
    }
}
